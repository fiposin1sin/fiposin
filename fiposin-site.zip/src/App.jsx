import React from 'react';

function App() {
  return (
    <div className='text-center p-4'>
      <h1 className='text-3xl font-bold'>Bem-vindo ao Fiposin</h1>
      <p>Website em construção.</p>
    </div>
  );
}

export default App;